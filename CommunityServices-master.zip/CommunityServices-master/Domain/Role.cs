﻿namespace CommunityServices.Domain
{
    public enum Role
    {
        ADMIN,
        MANAGER,
        RESIDENT
    }
}
